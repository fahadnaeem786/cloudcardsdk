//
//  Cloud_Card_SDK.h
//  Cloud Card SDK
//
//  Created by Fahad Naeem on 11/26/18.
//  Copyright © 2018 Cloud Card. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Cloud_Card_SDK.
FOUNDATION_EXPORT double Cloud_Card_SDKVersionNumber;

//! Project version string for Cloud_Card_SDK.
FOUNDATION_EXPORT const unsigned char Cloud_Card_SDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Cloud_Card_SDK/PublicHeader.h>

